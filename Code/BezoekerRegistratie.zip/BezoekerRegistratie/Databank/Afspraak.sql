﻿CREATE TABLE [dbo].[Afspraak]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [begintijd] DATETIME NOT NULL, 
    [eindtijd] DATETIME NOT NULL
)
