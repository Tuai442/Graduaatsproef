﻿CREATE TABLE [dbo].[Werknemer]
(
	[Id] INT NOT NULL PRIMARY KEY,
    [voornaam] VARCHAR(50) NOT NULL, 
    [naam] VARCHAR(50) NOT NULL, 
    [email] VARCHAR(50) NOT NULL, 
    [functie] VARCHAR(50) NOT NULL
)
