﻿using Xunit;
using Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Controller.Models;

namespace Controller.Tests
{
    public class BezoekerControllerTests
    {
        [Fact()]
        public void MeldBezoekerAanTest()
        {
            Bezoeker bezoeker = new Bezoeker();
            Assert.True(false, "This test needs an implementation");
        }
    }
}