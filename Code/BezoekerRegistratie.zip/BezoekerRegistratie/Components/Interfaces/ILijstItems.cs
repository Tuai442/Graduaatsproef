﻿namespace Components.Interfaces
{
    public interface ILijstItems
    {
        public string Id { get; }
        public string ItemNaam { get; }
    }
}