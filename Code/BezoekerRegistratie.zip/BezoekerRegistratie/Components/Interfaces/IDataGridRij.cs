﻿namespace Components.Interfaces
{
    internal interface IDataGridRij
    {

        public int GeefDataGridIndex { get; set; }
        public string Content { get; set; }
    }
}