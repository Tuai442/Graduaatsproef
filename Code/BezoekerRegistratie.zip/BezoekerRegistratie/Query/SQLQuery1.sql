﻿
--CREATE TABLE Bedrijven (
--    BedrijfId int,
--    Naam varchar(255),
--    BTW varchar(255),
--    Email varchar(255),
--    Adres varchar(255),
--    Telefoon varchar(255),
--    PRIMARY KEY (BedrijfId),
--);


--CREATE TABLE Werknemers (
--    WerknemerId int,
--    Voornaam varchar(255),
--    Achternaam varchar(255),
--    Email varchar(255),
--    Functie varchar(255),
--    BedrijfId int,
--    PRIMARY KEY (WerknemerId),
--    FOREIGN KEY (BedrijfId) REFERENCES Bedrijven(BedrijfId)
--);

SELECT * FROM Werknemers;